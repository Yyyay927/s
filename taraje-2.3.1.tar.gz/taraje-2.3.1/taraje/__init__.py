"""
    :Author: ampasmanusa (bancetzLaut) <0.ampasmanusa@gmail.com>
    :Created: 2022-03-19T23:30:18+07:00
    :Updated: 2023-01-24T11:01:53+07:00
    :Version: 2.3.1
    :Description: Taraje's Bot.

    """
